package constants;


/**
 * @date 
 * @author 
 * @description Interface class used to store APPLICATION CONSTANTS
 */
public interface ApplicationConstants {
	static final String Perfecto_Report ="Reports/";	
}
