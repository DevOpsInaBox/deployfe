package constants;

/**
 * @date 
 * @author 
 * @description Interface class used to store APPLICATION CONSTANTS
 */
public interface PerfectoConstants {

	static final String PERFECTO_URL="partners.perfectomobile.com";
	static final String PERFECTO_USRNAME="demo@newtglobal.com";
	static final String PERFECTO_PWD="DEMO123";
	static final String PERFECTO_BROWSER="mobileOS";
	static final String APP_URL="www.moneycontrol.com";
	
	
	
}
